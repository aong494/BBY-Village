@echo off
:: [Coding Partner] Arclight Server Starter

:: 1. Configuration
set JAR_NAME=arclight-neoforge-1.21.1.jar
set RAM=8G

echo Starting Arclight 1.21.1 NeoForge...
echo Please wait until "Done" or "Help" message appears.

:: 2. Run Server
java -Xms%RAM% -Xmx%RAM% -jar %JAR_NAME% nogui

:: 3. Force create plugins folder if it doesn't exist
if not exist plugins (
    echo Plugins folder not found. Creating now...
    mkdir plugins
)

echo Server process finished.
pause